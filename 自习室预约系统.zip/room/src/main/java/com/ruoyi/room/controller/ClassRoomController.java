package com.ruoyi.room.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.room.domain.ClassRoom;
import com.ruoyi.room.service.IClassRoomService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 教室管理Controller
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Controller
@RequestMapping("/room/classroom")
public class ClassRoomController extends BaseController
{
    private String prefix = "room/classroom";

    @Autowired
    private IClassRoomService classRoomService;

    @RequiresPermissions("room:classroom:view")
    @GetMapping()
    public String classroom()
    {
        return prefix + "/classroom";
    }

    /**
     * 查询教室管理列表
     */
    @RequiresPermissions("room:classroom:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(ClassRoom classRoom)
    {
        startPage();
        classRoom.setDictType("room_classroom");
        List<ClassRoom> list = classRoomService.selectClassRoomList(classRoom);
        return getDataTable(list);
    }

    /**
     * 导出教室管理列表
     */
    @RequiresPermissions("room:classroom:export")
    @Log(title = "教室管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(ClassRoom classRoom)
    {
        List<ClassRoom> list = classRoomService.selectClassRoomList(classRoom);
        ExcelUtil<ClassRoom> util = new ExcelUtil<ClassRoom>(ClassRoom.class);
        return util.exportExcel(list, "教室管理数据");
    }

    /**
     * 新增教室管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存教室管理
     */
    @RequiresPermissions("room:classroom:add")
    @Log(title = "教室管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(ClassRoom classRoom)
    {
        return toAjax(classRoomService.insertClassRoom(classRoom));
    }

    /**
     * 修改教室管理
     */
    @RequiresPermissions("room:classroom:edit")
    @GetMapping("/edit/{dictCode}")
    public String edit(@PathVariable("dictCode") Long dictCode, ModelMap mmap)
    {
        ClassRoom classRoom = classRoomService.selectClassRoomByDictCode(dictCode);
        mmap.put("classRoom", classRoom);
        return prefix + "/edit";
    }

    /**
     * 修改保存教室管理
     */
    @RequiresPermissions("room:classroom:edit")
    @Log(title = "教室管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(ClassRoom classRoom)
    {
        return toAjax(classRoomService.updateClassRoom(classRoom));
    }

    /**
     * 删除教室管理
     */
    @RequiresPermissions("room:classroom:remove")
    @Log(title = "教室管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(classRoomService.deleteClassRoomByDictCodes(ids));
    }
}
