package com.ruoyi.room.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/frontend")
public class FrontendController {

    @GetMapping("/test")
    public String classroom()
    {
        return "frontend";
    }
}
