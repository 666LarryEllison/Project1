package com.ruoyi.room.controller;

import java.util.Date;
import java.util.List;

import com.ruoyi.room.domain.RoomBooking;
import com.ruoyi.room.service.IRoomBookingService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.room.domain.RoomPlace;
import com.ruoyi.room.service.IRoomPlaceService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 预约管理Controller
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Controller
@RequestMapping("/room/place")
public class RoomPlaceController extends BaseController
{
    private String prefix = "room/place";

    @Autowired
    private IRoomPlaceService roomPlaceService;

    @Autowired
    private IRoomBookingService bookingService;

    @RequiresPermissions("room:place:view")
    @GetMapping()
    public String place()
    {
        return prefix + "/place";
    }

    /**
     * 查询预约管理列表
     */
    @RequiresPermissions("room:place:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(RoomPlace roomPlace)
    {
        startPage();
        List<RoomPlace> list = roomPlaceService.selectRoomPlaceList(roomPlace);

        long now = new Date().getTime();

        list.forEach(p -> {
            RoomBooking booking = new RoomBooking();
            booking.setPlaceId(p.getId());
            //查预约的数量
            List<RoomBooking> bookings = bookingService.selectRoomBookingList(booking);
            p.setBookingNum(bookings.size());
            bookings.forEach(b -> {
                //看当前时间是否有预约
                if (b.getStartTime().getTime() <= now && b.getEndTime().getTime() >= now){
                    //如果当前时间在开始和结束之间，说明有预约占用，标记为1
                    p.setCurrentBook(1);
                }
            });
        });


        return getDataTable(list);
    }

    /**
     * 导出预约管理列表
     */
    @RequiresPermissions("room:place:export")
    @Log(title = "预约管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(RoomPlace roomPlace)
    {
        List<RoomPlace> list = roomPlaceService.selectRoomPlaceList(roomPlace);
        ExcelUtil<RoomPlace> util = new ExcelUtil<RoomPlace>(RoomPlace.class);
        return util.exportExcel(list, "预约管理数据");
    }

    /**
     * 新增预约管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存预约管理
     */
    @RequiresPermissions("room:place:add")
    @Log(title = "预约管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(RoomPlace roomPlace)
    {
        return toAjax(roomPlaceService.insertRoomPlace(roomPlace));
    }

    /**
     * 修改预约管理
     */
    @RequiresPermissions("room:place:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        RoomPlace roomPlace = roomPlaceService.selectRoomPlaceById(id);
        mmap.put("roomPlace", roomPlace);
        return prefix + "/edit";
    }

    /**
     * 修改保存预约管理
     */
    @RequiresPermissions("room:place:edit")
    @Log(title = "预约管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(RoomPlace roomPlace)
    {
        return toAjax(roomPlaceService.updateRoomPlace(roomPlace));
    }

    /**
     * 删除预约管理
     */
    @RequiresPermissions("room:place:remove")
    @Log(title = "预约管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(roomPlaceService.deleteRoomPlaceByIds(ids));
    }
}
