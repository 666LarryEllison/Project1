package com.ruoyi.room.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.room.domain.RoomSeat;
import com.ruoyi.room.service.IRoomSeatService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 座位管理Controller
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Controller
@RequestMapping("/room/seat")
public class RoomSeatController extends BaseController
{
    private String prefix = "room/seat";

    @Autowired
    private IRoomSeatService roomSeatService;

    @RequiresPermissions("room:seat:view")
    @GetMapping()
    public String seat()
    {
        return prefix + "/seat";
    }

    /**
     * 查询座位管理列表
     */
    @RequiresPermissions("room:seat:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(RoomSeat roomSeat)
    {
        startPage();
        List<RoomSeat> list = roomSeatService.selectRoomSeatList(roomSeat);
        return getDataTable(list);
    }

    /**
     * 导出座位管理列表
     */
    @RequiresPermissions("room:seat:export")
    @Log(title = "座位管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(RoomSeat roomSeat)
    {
        List<RoomSeat> list = roomSeatService.selectRoomSeatList(roomSeat);
        ExcelUtil<RoomSeat> util = new ExcelUtil<RoomSeat>(RoomSeat.class);
        return util.exportExcel(list, "座位管理数据");
    }

    /**
     * 新增座位管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存座位管理
     */
    @RequiresPermissions("room:seat:add")
    @Log(title = "座位管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(RoomSeat roomSeat)
    {
        return toAjax(roomSeatService.insertRoomSeat(roomSeat));
    }

    /**
     * 修改座位管理
     */
    @RequiresPermissions("room:seat:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        RoomSeat roomSeat = roomSeatService.selectRoomSeatById(id);
        mmap.put("roomSeat", roomSeat);
        return prefix + "/edit";
    }

    /**
     * 修改保存座位管理
     */
    @RequiresPermissions("room:seat:edit")
    @Log(title = "座位管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(RoomSeat roomSeat)
    {
        return toAjax(roomSeatService.updateRoomSeat(roomSeat));
    }

    /**
     * 删除座位管理
     */
    @RequiresPermissions("room:seat:remove")
    @Log(title = "座位管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(roomSeatService.deleteRoomSeatByIds(ids));
    }
}
