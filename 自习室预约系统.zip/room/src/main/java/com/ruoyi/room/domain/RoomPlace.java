package com.ruoyi.room.domain;

import java.util.List;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 预约管理对象 room_place
 * 
 * @author Shawn
 * @date 2024-02-22
 */
public class RoomPlace extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /**  */
    private Long id;

    /** 座位号 */
    @Excel(name = "座位号")
    private String code;

    /** 所属自习室 */
    @Excel(name = "所属自习室")
    private String roomId;

    /** 预约信息信息 */
    private List<RoomBooking> roomBookingList;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setCode(String code) 
    {
        this.code = code;
    }

    public String getCode() 
    {
        return code;
    }
    public void setRoomId(String roomId) 
    {
        this.roomId = roomId;
    }

    public String getRoomId() 
    {
        return roomId;
    }

    public List<RoomBooking> getRoomBookingList()
    {
        return roomBookingList;
    }

    public void setRoomBookingList(List<RoomBooking> roomBookingList)
    {
        this.roomBookingList = roomBookingList;
    }


    //当前座位的预约数量
    private int bookingNum;

    public int getBookingNum() {
        return bookingNum;
    }

    public void setBookingNum(int bookingNum) {
        this.bookingNum = bookingNum;
    }

    //是否当前被预约，1=是，0=否
    //如果被预约，则红色显示，否则绿色显示
    private int currentBook;

    public int getCurrentBook() {
        return currentBook;
    }

    public void setCurrentBook(int currentBook) {
        this.currentBook = currentBook;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("code", getCode())
            .append("roomId", getRoomId())
            .append("roomBookingList", getRoomBookingList())
            .toString();
    }
}
