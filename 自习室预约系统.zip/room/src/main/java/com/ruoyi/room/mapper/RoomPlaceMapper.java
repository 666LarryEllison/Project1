package com.ruoyi.room.mapper;

import java.util.List;
import com.ruoyi.room.domain.RoomPlace;
import com.ruoyi.room.domain.RoomBooking;

/**
 * 预约管理Mapper接口
 * 
 * @author Shawn
 * @date 2024-02-22
 */
public interface RoomPlaceMapper 
{
    /**
     * 查询预约管理
     * 
     * @param id 预约管理主键
     * @return 预约管理
     */
    public RoomPlace selectRoomPlaceById(Long id);

    /**
     * 查询预约管理列表
     * 
     * @param roomPlace 预约管理
     * @return 预约管理集合
     */
    public List<RoomPlace> selectRoomPlaceList(RoomPlace roomPlace);

    /**
     * 新增预约管理
     * 
     * @param roomPlace 预约管理
     * @return 结果
     */
    public int insertRoomPlace(RoomPlace roomPlace);

    /**
     * 修改预约管理
     * 
     * @param roomPlace 预约管理
     * @return 结果
     */
    public int updateRoomPlace(RoomPlace roomPlace);

    /**
     * 删除预约管理
     * 
     * @param id 预约管理主键
     * @return 结果
     */
    public int deleteRoomPlaceById(Long id);

    /**
     * 批量删除预约管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteRoomPlaceByIds(String[] ids);

    /**
     * 批量删除预约信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteRoomBookingByPlaceIds(String[] ids);
    
    /**
     * 批量新增预约信息
     * 
     * @param roomBookingList 预约信息列表
     * @return 结果
     */
    public int batchRoomBooking(List<RoomBooking> roomBookingList);
    

    /**
     * 通过预约管理主键删除预约信息信息
     * 
     * @param id 预约管理ID
     * @return 结果
     */
    public int deleteRoomBookingByPlaceId(Long id);
}
