package com.ruoyi.room.mapper;

import java.util.List;
import com.ruoyi.room.domain.RoomSeat;

/**
 * 座位管理Mapper接口
 * 
 * @author Shawn
 * @date 2024-02-22
 */
public interface RoomSeatMapper 
{
    /**
     * 查询座位管理
     * 
     * @param id 座位管理主键
     * @return 座位管理
     */
    public RoomSeat selectRoomSeatById(Long id);

    /**
     * 查询座位管理列表
     * 
     * @param roomSeat 座位管理
     * @return 座位管理集合
     */
    public List<RoomSeat> selectRoomSeatList(RoomSeat roomSeat);

    /**
     * 新增座位管理
     * 
     * @param roomSeat 座位管理
     * @return 结果
     */
    public int insertRoomSeat(RoomSeat roomSeat);

    /**
     * 修改座位管理
     * 
     * @param roomSeat 座位管理
     * @return 结果
     */
    public int updateRoomSeat(RoomSeat roomSeat);

    /**
     * 删除座位管理
     * 
     * @param id 座位管理主键
     * @return 结果
     */
    public int deleteRoomSeatById(Long id);

    /**
     * 批量删除座位管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteRoomSeatByIds(String[] ids);
}
