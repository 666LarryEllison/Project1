package com.ruoyi.room.service;

import java.util.List;
import com.ruoyi.room.domain.ClassRoom;

/**
 * 教室管理Service接口
 * 
 * @author Shawn
 * @date 2024-02-22
 */
public interface IClassRoomService 
{
    /**
     * 查询教室管理
     * 
     * @param dictCode 教室管理主键
     * @return 教室管理
     */
    public ClassRoom selectClassRoomByDictCode(Long dictCode);

    /**
     * 查询教室管理列表
     * 
     * @param classRoom 教室管理
     * @return 教室管理集合
     */
    public List<ClassRoom> selectClassRoomList(ClassRoom classRoom);

    /**
     * 新增教室管理
     * 
     * @param classRoom 教室管理
     * @return 结果
     */
    public int insertClassRoom(ClassRoom classRoom);

    /**
     * 修改教室管理
     * 
     * @param classRoom 教室管理
     * @return 结果
     */
    public int updateClassRoom(ClassRoom classRoom);

    /**
     * 批量删除教室管理
     * 
     * @param dictCodes 需要删除的教室管理主键集合
     * @return 结果
     */
    public int deleteClassRoomByDictCodes(String dictCodes);

    /**
     * 删除教室管理信息
     * 
     * @param dictCode 教室管理主键
     * @return 结果
     */
    public int deleteClassRoomByDictCode(Long dictCode);
}
