package com.ruoyi.room.service;

import java.util.List;
import com.ruoyi.room.domain.RoomBooking;

/**
 * 预约信息Service接口
 * 
 * @author Shawn
 * @date 2024-02-22
 */
public interface IRoomBookingService 
{
    /**
     * 查询预约信息
     * 
     * @param id 预约信息主键
     * @return 预约信息
     */
    public RoomBooking selectRoomBookingById(Long id);

    /**
     * 查询预约信息列表
     * 
     * @param roomBooking 预约信息
     * @return 预约信息集合
     */
    public List<RoomBooking> selectRoomBookingList(RoomBooking roomBooking);

    //校验预约信息，防重复
    public int checkRoomBooking(RoomBooking roomBooking);
    /**
     * 新增预约信息
     * 
     * @param roomBooking 预约信息
     * @return 结果
     */
    public int insertRoomBooking(RoomBooking roomBooking);

    /**
     * 修改预约信息
     * 
     * @param roomBooking 预约信息
     * @return 结果
     */
    public int updateRoomBooking(RoomBooking roomBooking);

    /**
     * 批量删除预约信息
     * 
     * @param ids 需要删除的预约信息主键集合
     * @return 结果
     */
    public int deleteRoomBookingByIds(String ids);

    /**
     * 删除预约信息信息
     * 
     * @param id 预约信息主键
     * @return 结果
     */
    public int deleteRoomBookingById(Long id);
}
