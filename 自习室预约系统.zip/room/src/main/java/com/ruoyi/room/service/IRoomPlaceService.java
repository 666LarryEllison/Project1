package com.ruoyi.room.service;

import java.util.List;
import com.ruoyi.room.domain.RoomPlace;

/**
 * 预约管理Service接口
 * 
 * @author Shawn
 * @date 2024-02-22
 */
public interface IRoomPlaceService 
{
    /**
     * 查询预约管理
     * 
     * @param id 预约管理主键
     * @return 预约管理
     */
    public RoomPlace selectRoomPlaceById(Long id);

    /**
     * 查询预约管理列表
     * 
     * @param roomPlace 预约管理
     * @return 预约管理集合
     */
    public List<RoomPlace> selectRoomPlaceList(RoomPlace roomPlace);

    /**
     * 新增预约管理
     * 
     * @param roomPlace 预约管理
     * @return 结果
     */
    public int insertRoomPlace(RoomPlace roomPlace);

    /**
     * 修改预约管理
     * 
     * @param roomPlace 预约管理
     * @return 结果
     */
    public int updateRoomPlace(RoomPlace roomPlace);

    /**
     * 批量删除预约管理
     * 
     * @param ids 需要删除的预约管理主键集合
     * @return 结果
     */
    public int deleteRoomPlaceByIds(String ids);

    /**
     * 删除预约管理信息
     * 
     * @param id 预约管理主键
     * @return 结果
     */
    public int deleteRoomPlaceById(Long id);
}
