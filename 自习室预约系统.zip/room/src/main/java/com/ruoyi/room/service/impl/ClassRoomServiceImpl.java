package com.ruoyi.room.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.room.mapper.ClassRoomMapper;
import com.ruoyi.room.domain.ClassRoom;
import com.ruoyi.room.service.IClassRoomService;
import com.ruoyi.common.core.text.Convert;

/**
 * 教室管理Service业务层处理
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Service
public class ClassRoomServiceImpl implements IClassRoomService 
{
    @Autowired
    private ClassRoomMapper classRoomMapper;

    /**
     * 查询教室管理
     * 
     * @param dictCode 教室管理主键
     * @return 教室管理
     */
    @Override
    public ClassRoom selectClassRoomByDictCode(Long dictCode)
    {
        return classRoomMapper.selectClassRoomByDictCode(dictCode);
    }

    /**
     * 查询教室管理列表
     * 
     * @param classRoom 教室管理
     * @return 教室管理
     */
    @Override
    public List<ClassRoom> selectClassRoomList(ClassRoom classRoom)
    {
        return classRoomMapper.selectClassRoomList(classRoom);
    }

    /**
     * 新增教室管理
     * 
     * @param classRoom 教室管理
     * @return 结果
     */
    @Override
    public int insertClassRoom(ClassRoom classRoom)
    {
        classRoom.setCreateTime(DateUtils.getNowDate());
        return classRoomMapper.insertClassRoom(classRoom);
    }

    /**
     * 修改教室管理
     * 
     * @param classRoom 教室管理
     * @return 结果
     */
    @Override
    public int updateClassRoom(ClassRoom classRoom)
    {
        classRoom.setUpdateTime(DateUtils.getNowDate());
        return classRoomMapper.updateClassRoom(classRoom);
    }

    /**
     * 批量删除教室管理
     * 
     * @param dictCodes 需要删除的教室管理主键
     * @return 结果
     */
    @Override
    public int deleteClassRoomByDictCodes(String dictCodes)
    {
        return classRoomMapper.deleteClassRoomByDictCodes(Convert.toStrArray(dictCodes));
    }

    /**
     * 删除教室管理信息
     * 
     * @param dictCode 教室管理主键
     * @return 结果
     */
    @Override
    public int deleteClassRoomByDictCode(Long dictCode)
    {
        return classRoomMapper.deleteClassRoomByDictCode(dictCode);
    }
}
