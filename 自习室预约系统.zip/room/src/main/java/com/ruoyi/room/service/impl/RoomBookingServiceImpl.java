package com.ruoyi.room.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.room.mapper.RoomBookingMapper;
import com.ruoyi.room.domain.RoomBooking;
import com.ruoyi.room.service.IRoomBookingService;
import com.ruoyi.common.core.text.Convert;

/**
 * 预约信息Service业务层处理
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Service
public class RoomBookingServiceImpl implements IRoomBookingService 
{
    @Autowired
    private RoomBookingMapper roomBookingMapper;

    /**
     * 查询预约信息
     * 
     * @param id 预约信息主键
     * @return 预约信息
     */
    @Override
    public RoomBooking selectRoomBookingById(Long id)
    {
        return roomBookingMapper.selectRoomBookingById(id);
    }

    /**
     * 查询预约信息列表
     * 
     * @param roomBooking 预约信息
     * @return 预约信息
     */
    @Override
    public List<RoomBooking> selectRoomBookingList(RoomBooking roomBooking)
    {
        return roomBookingMapper.selectRoomBookingList(roomBooking);
    }

    @Override
    public int checkRoomBooking(RoomBooking roomBooking) {

        return roomBookingMapper.checkRoomBooking(roomBooking);
    }

    /**
     * 新增预约信息
     * 
     * @param roomBooking 预约信息
     * @return 结果
     */
    @Override
    public int insertRoomBooking(RoomBooking roomBooking)
    {
        return roomBookingMapper.insertRoomBooking(roomBooking);
    }

    /**
     * 修改预约信息
     * 
     * @param roomBooking 预约信息
     * @return 结果
     */
    @Override
    public int updateRoomBooking(RoomBooking roomBooking)
    {
        return roomBookingMapper.updateRoomBooking(roomBooking);
    }

    /**
     * 批量删除预约信息
     * 
     * @param ids 需要删除的预约信息主键
     * @return 结果
     */
    @Override
    public int deleteRoomBookingByIds(String ids)
    {
        return roomBookingMapper.deleteRoomBookingByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除预约信息信息
     * 
     * @param id 预约信息主键
     * @return 结果
     */
    @Override
    public int deleteRoomBookingById(Long id)
    {
        return roomBookingMapper.deleteRoomBookingById(id);
    }
}
