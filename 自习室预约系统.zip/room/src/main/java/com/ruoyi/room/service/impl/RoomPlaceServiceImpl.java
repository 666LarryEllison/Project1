package com.ruoyi.room.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import com.ruoyi.common.utils.StringUtils;
import org.springframework.transaction.annotation.Transactional;
import com.ruoyi.room.domain.RoomBooking;
import com.ruoyi.room.mapper.RoomPlaceMapper;
import com.ruoyi.room.domain.RoomPlace;
import com.ruoyi.room.service.IRoomPlaceService;
import com.ruoyi.common.core.text.Convert;

/**
 * 预约管理Service业务层处理
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Service
public class RoomPlaceServiceImpl implements IRoomPlaceService 
{
    @Autowired
    private RoomPlaceMapper roomPlaceMapper;

    /**
     * 查询预约管理
     * 
     * @param id 预约管理主键
     * @return 预约管理
     */
    @Override
    public RoomPlace selectRoomPlaceById(Long id)
    {
        return roomPlaceMapper.selectRoomPlaceById(id);
    }

    /**
     * 查询预约管理列表
     * 
     * @param roomPlace 预约管理
     * @return 预约管理
     */
    @Override
    public List<RoomPlace> selectRoomPlaceList(RoomPlace roomPlace)
    {
        return roomPlaceMapper.selectRoomPlaceList(roomPlace);
    }

    /**
     * 新增预约管理
     * 
     * @param roomPlace 预约管理
     * @return 结果
     */
    @Transactional
    @Override
    public int insertRoomPlace(RoomPlace roomPlace)
    {
        int rows = roomPlaceMapper.insertRoomPlace(roomPlace);
        insertRoomBooking(roomPlace);
        return rows;
    }

    /**
     * 修改预约管理
     * 
     * @param roomPlace 预约管理
     * @return 结果
     */
    @Transactional
    @Override
    public int updateRoomPlace(RoomPlace roomPlace)
    {
        roomPlaceMapper.deleteRoomBookingByPlaceId(roomPlace.getId());
        insertRoomBooking(roomPlace);
        return roomPlaceMapper.updateRoomPlace(roomPlace);
    }

    /**
     * 批量删除预约管理
     * 
     * @param ids 需要删除的预约管理主键
     * @return 结果
     */
    @Transactional
    @Override
    public int deleteRoomPlaceByIds(String ids)
    {
        roomPlaceMapper.deleteRoomBookingByPlaceIds(Convert.toStrArray(ids));
        return roomPlaceMapper.deleteRoomPlaceByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除预约管理信息
     * 
     * @param id 预约管理主键
     * @return 结果
     */
    @Transactional
    @Override
    public int deleteRoomPlaceById(Long id)
    {
        roomPlaceMapper.deleteRoomBookingByPlaceId(id);
        return roomPlaceMapper.deleteRoomPlaceById(id);
    }

    /**
     * 新增预约信息信息
     * 
     * @param roomPlace 预约管理对象
     */
    public void insertRoomBooking(RoomPlace roomPlace)
    {
        List<RoomBooking> roomBookingList = roomPlace.getRoomBookingList();
        Long id = roomPlace.getId();
        if (StringUtils.isNotNull(roomBookingList))
        {
            List<RoomBooking> list = new ArrayList<RoomBooking>();
            for (RoomBooking roomBooking : roomBookingList)
            {
                roomBooking.setPlaceId(id);
                list.add(roomBooking);
            }
            if (list.size() > 0)
            {
                roomPlaceMapper.batchRoomBooking(list);
            }
        }
    }
}
