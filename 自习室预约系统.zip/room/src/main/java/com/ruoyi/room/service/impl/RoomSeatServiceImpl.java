package com.ruoyi.room.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.room.mapper.RoomSeatMapper;
import com.ruoyi.room.domain.RoomSeat;
import com.ruoyi.room.service.IRoomSeatService;
import com.ruoyi.common.core.text.Convert;

/**
 * 座位管理Service业务层处理
 * 
 * @author Shawn
 * @date 2024-02-22
 */
@Service
public class RoomSeatServiceImpl implements IRoomSeatService 
{
    @Autowired
    private RoomSeatMapper roomSeatMapper;

    /**
     * 查询座位管理
     * 
     * @param id 座位管理主键
     * @return 座位管理
     */
    @Override
    public RoomSeat selectRoomSeatById(Long id)
    {
        return roomSeatMapper.selectRoomSeatById(id);
    }

    /**
     * 查询座位管理列表
     * 
     * @param roomSeat 座位管理
     * @return 座位管理
     */
    @Override
    public List<RoomSeat> selectRoomSeatList(RoomSeat roomSeat)
    {
        return roomSeatMapper.selectRoomSeatList(roomSeat);
    }

    /**
     * 新增座位管理
     * 
     * @param roomSeat 座位管理
     * @return 结果
     */
    @Override
    public int insertRoomSeat(RoomSeat roomSeat)
    {
        return roomSeatMapper.insertRoomSeat(roomSeat);
    }

    /**
     * 修改座位管理
     * 
     * @param roomSeat 座位管理
     * @return 结果
     */
    @Override
    public int updateRoomSeat(RoomSeat roomSeat)
    {
        return roomSeatMapper.updateRoomSeat(roomSeat);
    }

    /**
     * 批量删除座位管理
     * 
     * @param ids 需要删除的座位管理主键
     * @return 结果
     */
    @Override
    public int deleteRoomSeatByIds(String ids)
    {
        return roomSeatMapper.deleteRoomSeatByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除座位管理信息
     * 
     * @param id 座位管理主键
     * @return 结果
     */
    @Override
    public int deleteRoomSeatById(Long id)
    {
        return roomSeatMapper.deleteRoomSeatById(id);
    }
}
