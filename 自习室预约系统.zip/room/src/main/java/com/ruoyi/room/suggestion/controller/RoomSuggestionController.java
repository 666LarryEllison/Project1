package com.ruoyi.room.suggestion.controller;

import java.util.List;

import com.ruoyi.common.annotation.DataScope;
import com.ruoyi.common.core.domain.entity.SysUser;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.room.suggestion.domain.RoomSuggestion;
import com.ruoyi.room.suggestion.service.IRoomSuggestionService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 投诉建议Controller
 * 
 * @author Shawn
 * @date 2024-02-21
 */
@Controller
@RequestMapping("/room/suggestion")
public class RoomSuggestionController extends BaseController
{
    private String prefix = "room/suggestion";

    @Autowired
    private IRoomSuggestionService roomSuggestionService;

    @RequiresPermissions("room:suggestion:view")
    @GetMapping()
    public String suggestion()
    {
        return prefix + "/suggestion";
    }

    /**
     * 查询投诉建议列表
     */
    @RequiresPermissions("room:suggestion:list")
    @PostMapping("/list")
    @ResponseBody
    @DataScope(userAlias = "u",deptAlias = "t")
    public TableDataInfo list(RoomSuggestion roomSuggestion)
    {
        startPage();
        List<RoomSuggestion> list = roomSuggestionService.selectRoomSuggestionList(roomSuggestion);
        return getDataTable(list);
    }

    /**
     * 导出投诉建议列表
     */
    @RequiresPermissions("room:suggestion:export")
    @Log(title = "投诉建议", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(RoomSuggestion roomSuggestion)
    {
        List<RoomSuggestion> list = roomSuggestionService.selectRoomSuggestionList(roomSuggestion);
        ExcelUtil<RoomSuggestion> util = new ExcelUtil<RoomSuggestion>(RoomSuggestion.class);
        return util.exportExcel(list, "投诉建议数据");
    }

    /**
     * 新增投诉建议
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存投诉建议
     */
    @RequiresPermissions("room:suggestion:add")
    @Log(title = "投诉建议", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(RoomSuggestion roomSuggestion)
    {
        SysUser user = getSysUser();
        roomSuggestion.setUserId(user.getUserId());
        roomSuggestion.setCreateBy(user.getUserName());
        roomSuggestion.setDeptId(user.getDeptId());
        return toAjax(roomSuggestionService.insertRoomSuggestion(roomSuggestion));
    }

    /**
     * 修改投诉建议
     */
    @RequiresPermissions("room:suggestion:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        RoomSuggestion roomSuggestion = roomSuggestionService.selectRoomSuggestionById(id);
        mmap.put("roomSuggestion", roomSuggestion);
        return prefix + "/edit";
    }

    /**
     * 修改保存投诉建议
     */
    @RequiresPermissions("room:suggestion:edit")
    @Log(title = "投诉建议", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(RoomSuggestion roomSuggestion)
    {
        roomSuggestion.setUpdateBy(getSysUser().getUserName());
        return toAjax(roomSuggestionService.updateRoomSuggestion(roomSuggestion));
    }

    /**
     * 删除投诉建议
     */
    @RequiresPermissions("room:suggestion:remove")
    @Log(title = "投诉建议", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(roomSuggestionService.deleteRoomSuggestionByIds(ids));
    }
}
