package com.ruoyi.room.suggestion.service;

import java.util.List;
import com.ruoyi.room.suggestion.domain.RoomSuggestion;

/**
 * 投诉建议Service接口
 * 
 * @author Shawn
 * @date 2024-02-21
 */
public interface IRoomSuggestionService 
{
    /**
     * 查询投诉建议
     * 
     * @param id 投诉建议主键
     * @return 投诉建议
     */
    public RoomSuggestion selectRoomSuggestionById(Long id);

    /**
     * 查询投诉建议列表
     * 
     * @param roomSuggestion 投诉建议
     * @return 投诉建议集合
     */
    public List<RoomSuggestion> selectRoomSuggestionList(RoomSuggestion roomSuggestion);

    /**
     * 新增投诉建议
     * 
     * @param roomSuggestion 投诉建议
     * @return 结果
     */
    public int insertRoomSuggestion(RoomSuggestion roomSuggestion);

    /**
     * 修改投诉建议
     * 
     * @param roomSuggestion 投诉建议
     * @return 结果
     */
    public int updateRoomSuggestion(RoomSuggestion roomSuggestion);

    /**
     * 批量删除投诉建议
     * 
     * @param ids 需要删除的投诉建议主键集合
     * @return 结果
     */
    public int deleteRoomSuggestionByIds(String ids);

    /**
     * 删除投诉建议信息
     * 
     * @param id 投诉建议主键
     * @return 结果
     */
    public int deleteRoomSuggestionById(Long id);
}
