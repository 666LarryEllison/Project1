package com.ruoyi.room.suggestion.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.room.suggestion.mapper.RoomSuggestionMapper;
import com.ruoyi.room.suggestion.domain.RoomSuggestion;
import com.ruoyi.room.suggestion.service.IRoomSuggestionService;
import com.ruoyi.common.core.text.Convert;

/**
 * 投诉建议Service业务层处理
 * 
 * @author Shawn
 * @date 2024-02-21
 */
@Service
public class RoomSuggestionServiceImpl implements IRoomSuggestionService 
{
    @Autowired
    private RoomSuggestionMapper roomSuggestionMapper;

    /**
     * 查询投诉建议
     * 
     * @param id 投诉建议主键
     * @return 投诉建议
     */
    @Override
    public RoomSuggestion selectRoomSuggestionById(Long id)
    {
        return roomSuggestionMapper.selectRoomSuggestionById(id);
    }

    /**
     * 查询投诉建议列表
     * 
     * @param roomSuggestion 投诉建议
     * @return 投诉建议
     */
    @Override
    public List<RoomSuggestion> selectRoomSuggestionList(RoomSuggestion roomSuggestion)
    {
        return roomSuggestionMapper.selectRoomSuggestionList(roomSuggestion);
    }

    /**
     * 新增投诉建议
     * 
     * @param roomSuggestion 投诉建议
     * @return 结果
     */
    @Override
    public int insertRoomSuggestion(RoomSuggestion roomSuggestion)
    {
        roomSuggestion.setCreateTime(DateUtils.getNowDate());
        return roomSuggestionMapper.insertRoomSuggestion(roomSuggestion);
    }

    /**
     * 修改投诉建议
     * 
     * @param roomSuggestion 投诉建议
     * @return 结果
     */
    @Override
    public int updateRoomSuggestion(RoomSuggestion roomSuggestion)
    {
        roomSuggestion.setUpdateTime(DateUtils.getNowDate());
        return roomSuggestionMapper.updateRoomSuggestion(roomSuggestion);
    }

    /**
     * 批量删除投诉建议
     * 
     * @param ids 需要删除的投诉建议主键
     * @return 结果
     */
    @Override
    public int deleteRoomSuggestionByIds(String ids)
    {
        return roomSuggestionMapper.deleteRoomSuggestionByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除投诉建议信息
     * 
     * @param id 投诉建议主键
     * @return 结果
     */
    @Override
    public int deleteRoomSuggestionById(Long id)
    {
        return roomSuggestionMapper.deleteRoomSuggestionById(id);
    }
}
